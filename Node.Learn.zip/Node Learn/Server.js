var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
 
mongoose.connect('mongodb://localhost:27017/');

var mssql =require('mssql');

var SQLconfig = require('./config/SQLconfig');
var mongodb = require('./data/mongodb');

var router = express.Router();

var app = express();

// parse application/x-www-form-urlencoded 
app.use(bodyParser.urlencoded({ extended: false })) 
// parse application/json 
app.use(bodyParser.json())



var customer = require('./Router/CustomerRouter');
app.use('/', customer);


app.use('/Sql',function(req,res){
	mssql.connect(SQLconfig(), function(err) {
    // ... error checks 
	if(err !=null){console.dir(err)};
    // Query 
 
    var request = new mssql.Request();
    request.query('SELECT top 1 * FROM [TescoConfiguration_GAPI_R1.2].[dbo].[ConfigSectionValues]', function(err, recordset) {
        // ... error checks 
 
        // console.dir(recordset);
		res.send(recordset);
		
    });
	});

	// res.send("Welcome to Node API");
});

app.use('/',function(req,res){
	 res.send("Welcome to Node API");
});
app.listen(1000,function(req,res){
	console.log("Server runing");
});