module.exports = function() {
    return config = {
    user: 'testUser',
    password: 'testUser',
    server: 'VDI01T8AHSC467', // You can use 'localhost\\instance' to connect to named instance 
    database: 'TescoConfiguration_GAPI_R1.2',
 
    options: {
        encrypt: false // Use this if you're on Windows Azure 
    }
}
};

